# ONE CITY: SURVIVAL — Stage 1 Prototype

Multiplayer foundation: browser clients connect to an authoritative Node.js
server, each gets a unique player, and everyone sees everyone else move
around in real time.

## Run it

```bash
npm install
npm start
```

Then open **http://localhost:3000** in two (or more) separate browser
windows/tabs. Click **PLAY** in each. You should see:

- Each window shows its own character in third person.
- Moving in one window (WASD + mouse look) shows that player moving smoothly
  in the other window(s), with a colored capsule + name tag.
- The HUD in the top-left shows a live "ONLINE" count.
- Press **F3** in-game to toggle a debug overlay: FPS, ping, player count,
  tick rate, your position, and connection status.

## Controls

| Key | Action |
|---|---|
| WASD | Move |
| Mouse (after clicking into the game) | Look around |
| Space | Jump |
| Shift | Sprint |
| C | Crouch |
| Esc | Release mouse |
| F3 | Toggle debug overlay |

## What's implemented (Stage 1)

- Express server serving the client, Socket.IO for real-time messaging.
- Server-authoritative player state: the server is the source of truth for
  position, validates/clips movement server-side (basic anti-teleport), and
  broadcasts a snapshot of all players at a fixed 20Hz tick — not a broadcast
  per keystroke.
- Client-side prediction for your own player (instant, responsive movement)
  and interpolation for remote players (no teleporting/jitter from network
  updates).
- Title screen → connecting → waiting → in-game flow (the actual lobby
  countdown/2–10-player gate is Stage 3, per the build plan — right now it
  drops you in shortly after connecting so you can verify the pipe works).
- A flat ground + scattered placeholder buildings so there's something to
  look at; this is a stand-in for the real modular city (Stage 2).
- Debug overlay (F3): fps, ping, player count, tick rate, position, connection.

## What's NOT in Stage 1 yet (by design — later stages)

Health/elimination, match/round system, events (blackout, flood, etc.),
safe zones, inventory, interactions, NPCs, real city geometry, sound. See
`plan.md`-equivalent in our conversation for the staged roadmap — Stage 2
picks up with the real city + collisions.

## Project structure

```
one-city-survival/
  server/
    index.js       — Express + Socket.IO, authoritative game state
  client/
    index.html      — screens (title/how-to/status/HUD/debug) + canvas
    css/style.css    — dark survival-game UI
    js/main.js       — Three.js scene, local player, remote interpolation
    js/network.js    — socket.io client wrapper
  package.json
```

## Notes on testing

I wasn't able to run `npm install` or boot the server in the sandbox this
was built in (no network access there), so this hasn't been live-tested with
real browser connections yet. The server file passes a Node syntax check and
the client modules pass ES module syntax checks, but please run the two-tab
test above and tell me what happens — if anything breaks, paste the error
(browser console + terminal output) and I'll fix it before we move to Stage 2.
